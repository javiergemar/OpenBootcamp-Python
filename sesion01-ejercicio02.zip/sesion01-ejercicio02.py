# Desde la consola de python almacena la cadena
# “Hola mundo!” en una variable y muéstrala.

saludo = 'Hola mundo!'
print(saludo)