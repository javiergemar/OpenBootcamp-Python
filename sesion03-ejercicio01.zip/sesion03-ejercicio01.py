# Para este ejercicio tenéis que crear en la consola de python variables
# que representen los siguientes datos de un contacto:
#
# - Nombre
# - Apellidos
# - Edad
# - Email
# - Teléfono
# - Casado (verdadero o falso)
# - Con Hijos (verdadero o falso)
# - Lista de amigos
# - Películas vistas (diccionario con clave y valor. El valor será el título de la película)

nombre = ''
apellidos = ''
edad = int()
email = ''
telefono = int()
casado = False
tieneHijos = False
amigos = []
pelis = {'identificador': 'tituloPeli'}
print(nombre)
print(apellidos)
print(edad)
print(email)
print(telefono)
print(casado)
print(tieneHijos)
print(amigos)
print(pelis)
