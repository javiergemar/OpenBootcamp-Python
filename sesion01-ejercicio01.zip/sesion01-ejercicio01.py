# Desde la consola de python, debes de imprimir las siguientes cadenas de texto:

# Hola, soy [tu_nombre]
# Estoy empezando el curso de python
# Espero aprender mucho


print("Hola, soy Javier")
print("Estoy empezando el curso de python")
print("Espero aprender mucho")
